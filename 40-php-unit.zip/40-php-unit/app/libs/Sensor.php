<?php
require(__DIR__ . '/whichBrowser/bootstrap.php'); // Dodanie autoloadera dla zewnętrznych bibliotek
class Sensor {
    /**
     * Sprawdza, czy aplikacja działa lokalnie.
     * @return string Adres IP lokalnej maszyny.
     */
    public function isLocal() {
        $localIP = getHostByName(getHostName());  // Pobranie adresu IP lokalnej maszyny
        $serverIP = $_SERVER["SERVER_ADDR"];  // Pobranie adresu IP serwera

        return $localIP;
    }

    /**
     * Pobiera adres IP klienta.
     * @param mixed $getProxy Wartość opcjonalna, domyślnie null.
     * @return string Adres IP klienta.
     */
    public function addrIp($getProxy = null) {
        $remoteAddr = $_SERVER["REMOTE_ADDR"];  // Pobranie adresu IP klienta
        $httpForwarder = $_SERVER["HTTP_X_FORWARDER_FOR"];  // Pobranie adresu IP pośrednika (jeśli dostępny)
        return $remoteAddr; //???
    }

    /**
     * Pobiera informacje o przeglądarce klienta.
     * @return string Informacje o przeglądarce.
     */
    public function browser() {
        $result = new WhichBrowser\Parser(getallheaders());  // Analiza nagłówków HTTP
        $out = $result->browser->toString();  // Pobranie informacji o przeglądarce

        return $out;
    }

    /**
     * Pobiera informacje o systemie klienta.
     * @return string Informacje o systemie.
     */
    public function system() {
        $result = new WhichBrowser\Parser(getallheaders());  // Analiza nagłówków HTTP
        $out = $result->os->toString();  // Pobranie informacji o systemie

        return $out;
    }

    /**
     * Generuje unikalny odcisk palca na podstawie nagłówków HTTP.
     * @param string $algo Algorytm używany do generowania hasha. Domyślnie "sha512".
     * @return string Odcisk palca.
     */
    public function genFingerprint($algo = "sha512") {
        $UserAgent = $_SERVER['HTTP_USER_AGENT'];  // Pobranie nagłówka User-Agent
        $hash = hash_hmac($algo, $UserAgent, hash($algo, $UserAgent), true);  // Generowanie hasha HMAC

        return $hash;
    }
}
?>
