<?php

class DataBaseConn {
    // Zmienne prywatne do przechowywania danych połączenia z bazą danych
    private String $host;
    private String $user;
    private String $pw;
    private String $db;

    // Konstruktor klasy inicjalizujący zmienne host, user, pw, db
    public function __construct(String $host, String $user, String $pw, String $db) {
        $this->host = $host;
        $this->user = $user;
        $this->pw = $pw;
        $this->db = $db;
    }

    // Metoda put() dodająca nowy rekord do tabeli
    public function put(String $table, $columns, $values) {
        // Utworzenie nowego obiektu mysqli i nawiązanie połączenia
        $mysqli = new mysqli($this->host, $this->user, $this->pw, $this->db);

        // Sprawdzenie, czy połączenie zostało ustanowione
        if ($mysqli -> connect_errno) {
            echo "FAILED CONNECTION";
            return;
        }

        // Utworzenie zapytania SQL do wstawienia rekordu
        $query = "INSERT INTO ".$table." (".$columns.") VALUES (".$values.");";

        $allOk = false;

        // Wykonanie zapytania i sprawdzenie wyniku
        if($mysqli->query($query) === TRUE) {
            echo "ADDED RECORD OK";
            $allOk = true;
        } else {
            echo "ERROR: ".$mysqli->error;
        }

        // Zamknięcie połączenia z bazą danych
        $mysqli->close();
        return $allOk;
    }

    // Metoda get() pobierająca dane z tabeli na podstawie warunków
    public function get(String $table, $columns, $arrayOptions) {
        $mysqli = new mysqli($this->host, $this->user, $this->pw, $this->db);

        if ($mysqli -> connect_errno) {
            echo "FAILED CONNECTION";
            return;
        }

        // Utworzenie zapytania SQL do pobrania danych z tabeli
        $query = "SELECT ".$columns." FROM ".$table." WHERE ".$arrayOptions.";";

        $result = $mysqli->query($query);

        $allOk = false;

        // Wyświetlenie wyników zapytania
        if($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                print_r($row);
            }
            $allOk = true;
        } else {
            echo "Brak wynikow";
        }

        $mysqli->close();
        return $allOk;
    }

    // Metoda delete() usuwająca rekordy z tabeli na podstawie warunków
    public function delete(String $table, String $conditions) {
        $mysqli = new mysqli($this->host, $this->user, $this->pw, $this->db);

        if ($mysqli -> connect_errno) {
            echo "FAILED CONNECTION";
            return;
        }

        // Utworzenie zapytania SQL do usunięcia rekordów
        $query = "DELETE FROM ".$table." WHERE ".$conditions.";";

        $result = $mysqli->query($query);

        $allOk = false;

        // Wyświetlenie komunikatu o usunięciu rekordów
        if($result) {
            echo "Usunieto rekordy";
            $allOk = true;
        } else {
            echo "Brak wynikow";
        }

        $mysqli->close();
        return $allOk;
    }
}

?>
