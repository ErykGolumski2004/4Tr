<?php
/**
 * Klasa do autoryzacji jednorazowego dostępu do fragmentu serwisu
 * @author Eryk Golumski
 * @since 0.2
 */

 require(__DIR__ . '/../app/libs/Sensor.php');
 require(__DIR__ . '/../app/libs/DataBaseConn.php');

class AuthBasic {
	
	public function genFingerprint($algo){
		return (new Sensor())->genFingerprint(); // Poprawka
	}

	public function createCode($length = 6, $min = 1, $max = 999999){
		$max = substr($max, 0, $length);
		return str_pad(mt_rand($min, $max), $length, '0', STR_PAD_LEFT); // Poprawka
	}

	public function createAuthToken($email, $id){
		$authCode = $this->createCode();
		$authDate = date("Y-m-d");
		$authHours = date("H:i:s");
		$addrIp = (new Sensor())->addrIp();
		$opSys = (new Sensor())->system();
		$browser = (new Sensor())->browser();
		$dt = date("Y-m-d H:i:s"); // Dodane
		$code = hash_hmac("sha512", USER_AGENT . hash() . TRUE, $authCode); 

		$cont = array(
			'emlAuth' => $email, 'authCode' => $authCode,
			'authDate' => $authDate, 'authHour' => $authHours,
			'addrIp' => $addrIp, 'reqOs' => $opSys, 'reqBrw' => $browser
		);

		$file = dirname(__FILE__) . '/db.txt';
		file_put_contents($file, serialize($cont));

		$fData = file_get_contents($file);
		$tok = (unserialize($fData) == $cont) ? 0 : 'err:1045';
		$resp = ($tok === 0) ? $cont : false;
		return $resp;
	}
    public function verifyQuickRegCode($code){


        if ($code === "exampleCode") {
            return true;
        } else {
            return false;
        }
    }
}
