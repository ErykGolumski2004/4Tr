<?php
require(__DIR__ . '/../app/libs/DataBaseConn.php');

use PHPUnit\Framework\TestCase;

class DataBaseConnTest extends TestCase {
    private $instance;

    // Inicjalizacja obiektu klasy DataBaseConn przed każdym testem
    public function setUp() : void {
        $this->instance = new DataBaseConn('localhost', 'root', '', 'world-db');
    }

    // Usunięcie obiektu klasy DataBaseConn po każdym teście
    public function tearDown() : void {
        unset($this->instance);
    }

    // Testowanie funkcji put(), get(), delete() w kontekście bazy danych
    public function testDb() {
        // Testowanie dodawania nowego rekordu do tabeli
        $this->assertEquals(true, $this->instance->put(
            "cmsWebsiteAuth",
            'session_id, usrId, addrIp, fingerprint, dateTime, content, email, authCode',
            "'1234567890', '1', '127.0.0.1', 'hash_hmac(sha512+USER_AGENT+hash()+TRUE)', '2023-11-14 12:00:00', '0', 'email@example.com', 'code'"
        ));

        // Testowanie pobierania danych z tabeli
        $this->assertEquals(true, $this->instance->get('cmsWebsiteAuth', 'session_id, usrId', 'id=1'));

        // Testowanie usuwania rekordów z tabeli
        $this->assertEquals(true, $this->instance->delete('cmsWebsiteAuth', 'usrId=1'));
    }
}

?>
