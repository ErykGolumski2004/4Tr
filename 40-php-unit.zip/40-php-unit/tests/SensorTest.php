<?php

require(__DIR__ . '/../app/libs/Sensor.php');

use PHPUnit\Framework\TestCase;

class SensorTest extends TestCase {
    private $instance;

    // Inicjalizacja obiektu klasy Sensor przed każdym testem
    public function setUp() : void {
        $this->instance = new Sensor();
    }

    // Usunięcie obiektu klasy Sensor po każdym teście
    public function tearDown() : void {
        unset($this->instance);
    }

    // Testowanie funkcji isLocal()
    public function testIsLocal() {
        $out = $this->instance->isLocal();
        $this->assertIsString($out);
        
        // Przykładowe dane dla testu
        $this->assertEquals('172.22.128.1', $out);
    }

    // Testowanie funkcji addrIp()
    public function testAddrIp() {
        $out = $this->instance->addrIp();
    
        // Jeśli addrIp() zwraca null, to akceptujemy ten wynik
        if ($out === null) {
            $this->assertNull($out);
        } else {
            $this->assertIsString($out);
            
            // Sprawdzenie, czy rzeczywiste IP jest adresem IP
            $this->assertRegExp('/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/', $out);
        }
    }

    // Testowanie funkcji browser()
    public function testBrowser() {
        // Sprawdzenie, czy funkcja getallheaders() istnieje przed jej użyciem
        if (function_exists('getallheaders')) {
            $out = $this->instance->browser();
            $this->assertIsString($out);
            
            // Przykładowe dane dla testu
            $this->assertStringContainsString('Chrome', $out);
        } else {
            $this->markTestSkipped('Funkcja getallheaders() nie jest dostępna.');
        }
    }

    // Testowanie funkcji system()
    public function testSystem() {
        // Sprawdzenie, czy funkcja getallheaders() istnieje przed jej użyciem
        if (function_exists('getallheaders')) {
            $out = $this->instance->system();
            $this->assertIsString($out);
            
            // Przykładowe dane dla testu
            $this->assertStringContainsString('Windows', $out);
        } else {
            $this->markTestSkipped('Funkcja getallheaders() nie jest dostępna.');
        }
    }

    // Testowanie funkcji genFingerprint()
    public function testGenFingerprint() {
        // Sprawdzenie, czy metoda assertRegExp() istnieje przed jej użyciem
        if (method_exists($this, 'assertRegExp')) {
            $out = $this->instance->genFingerprint();
            $this->assertIsString($out);
            
            // Przykładowe dane dla testu
            $this->assertRegExp('/^[a-f0-9]{128}$/', $out);
        } else {
            $this->markTestSkipped('Metoda assertRegExp() nie jest dostępna.');
        }
    }
}

?>
